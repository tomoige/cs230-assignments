PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS artists (
    artist_id INTEGER PRIMARY KEY,
    artist_name TEXT NOT NULL,
    genre TEXT NOT NULL,
    monthly_listeners INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS albums (
    album_id INTEGER PRIMARY KEY,
    album_name TEXT NOT NULL,
    release_year INTEGER NOT NULL,
    number_of_listens INTEGER NOT NULL,
    artist_id INTEGER NOT NULL,
    FOREIGN KEY (artist_id) REFERENCES artists (artist_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS songs (
    song_id INTEGER PRIMARY KEY,
    song_name TEXT NOT NULL,
    release_year INTEGER NOT NULL,
    album_id INTEGER NOT NULL,
    FOREIGN KEY (album_id) REFERENCES albums (album_id) ON DELETE CASCADE
);

INSERT OR IGNORE INTO artists (artist_id, artist_name, genre, monthly_listeners) VALUES
    (1, 'The Weeknd', 'R&B/Pop', 112000000),
    (2, 'Dua Lipa', 'Pop', 76000000);

INSERT OR IGNORE INTO albums (album_id, album_name, release_year, number_of_listens, artist_id) VALUES
    (101, 'After Hours', 2020, 4200000000, 1),
    (102, 'Dawn FM', 2022, 1700000000, 1),
    (103, 'Beauty Behind the Madness', 2015, 3800000000, 1),
    (201, 'Future Nostalgia', 2020, 2900000000, 2),
    (202, 'Radical Optimism', 2024, 620000000, 2);

INSERT OR IGNORE INTO songs (song_id, song_name, release_year, album_id) VALUES
    (1001, 'Blinding Lights', 2020, 101),
    (1002, 'Save Your Tears', 2020, 101),
    (1003, 'In Your Eyes', 2020, 101),
    (1004, 'Take My Breath', 2022, 102),
    (1005, 'Sacrifice', 2022, 102),
    (1006, 'Can''t Feel My Face', 2015, 103),
    (1007, 'The Hills', 2015, 103),
    (2001, 'Don''t Start Now', 2020, 201),
    (2002, 'Levitating', 2020, 201),
    (2003, 'Houdini', 2024, 202);
