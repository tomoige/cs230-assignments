const songInputs = {
  song_id: document.getElementById("song_id"),
  song_name: document.getElementById("song_name"),
  release_year: document.getElementById("release_year"),
  album_id: document.getElementById("album_id")
};

function songPayload() {
  return {
    song_id: Number(songInputs.song_id.value),
    song_name: songInputs.song_name.value.trim(),
    release_year: Number(songInputs.release_year.value),
    album_id: Number(songInputs.album_id.value)
  };
}

function renderSongs(songs) {
  const body = document.getElementById("songs-body");
  body.innerHTML = songs
    .map(
      (song) => `
    <tr>
      <td>${song.song_id}</td>
      <td>${song.song_name}</td>
      <td>${song.release_year}</td>
      <td>${song.album_id}</td>
    </tr>
  `
    )
    .join("");
}

async function loadSongs() {
  try {
    const response = await request("/songs");
    const songs = response.data || [];
    renderSongs(songs);
    setStatus(`Loaded ${songs.length} songs.`);
  } catch (error) {
    setStatus(error.message, true);
  }
}

document.getElementById("create-song").addEventListener("click", async () => {
  try {
    await request("/songs", {
      method: "POST",
      body: JSON.stringify(songPayload())
    });
    setStatus("Song created.");
    loadSongs();
  } catch (error) {
    setStatus(error.message, true);
  }
});

document.getElementById("update-song").addEventListener("click", async () => {
  try {
    const data = songPayload();
    await request(`/songs/${data.song_id}`, {
      method: "PUT",
      body: JSON.stringify(data)
    });
    setStatus("Song updated.");
    loadSongs();
  } catch (error) {
    setStatus(error.message, true);
  }
});

document.getElementById("delete-song").addEventListener("click", async () => {
  try {
    const songId = Number(songInputs.song_id.value);
    await request(`/songs/${songId}`, { method: "DELETE" });
    setStatus("Song deleted.");
    loadSongs();
  } catch (error) {
    setStatus(error.message, true);
  }
});

document.getElementById("refresh-songs").addEventListener("click", loadSongs);

loadSongs();
